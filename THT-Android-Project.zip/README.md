# THT Native Android Gate

A native Android project with no third-party runtime or Python requirement on the phone.

## Device compatibility
- Minimum Android: 5.0 (API 21)
- Target Android: API 35
- No AndroidX
- No third-party libraries
- Uses only Android platform APIs and HTTPS
- One APK architecture; no ABI-specific native code

## What happens on the phone
1. First launch asks once for an OpenAI API key.
2. The key is stored in the app's private SharedPreferences.
3. Paste a THT image request.
4. The app automatically loads all embedded governing rules/history.
5. It runs semantic validation using GPT-5.6 Sol.
6. If validation fails, it automatically repairs and revalidates up to 3 passes.
7. A deterministic Java gate independently checks that every mandatory check is PASS and every known-failure veto is proven absent.
8. Only then can GPT-Image-2 be called.
9. Exactly one PNG is generated.
10. The image is saved to Pictures/The Human Thread.
11. A local audit record and SHA-256 hashes are saved automatically.

## No bypass
There is no button or code path to skip validation and call image generation directly.

## Building
This folder is a standard Android Gradle project. Open it in Android Studio and build an APK, or use:
`gradle assembleDebug`
with Android SDK 35 installed.

The delivered project itself has no external runtime dependencies, but compiling Android source into an APK requires the Android build toolchain once. After an APK is built, the phone needs only the installed APK and internet access.

## API key
For a personal local installation the key is stored in app-private storage. For public distribution, do not ship a personal API key in the APK; use a server-side token broker instead.
