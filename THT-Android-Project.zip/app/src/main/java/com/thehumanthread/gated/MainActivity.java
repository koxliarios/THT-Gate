package com.thehumanthread.gated;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText requestBox;
    private TextView status;
    private Button generateButton, keyButton;
    private ImageView imageView;
    private String rulesJson, historyJson, validatorSystem;
    private SharedPreferences prefs;

    private static final String RESPONSES_URL = "https://api.openai.com/v1/responses";
    private static final String IMAGES_URL = "https://api.openai.com/v1/images/generations";
    private static final String VALIDATOR_MODEL = "gpt-5.6-sol";
    private static final String IMAGE_MODEL = "gpt-image-2";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("tht_secure_local", MODE_PRIVATE);
        try {
            rulesJson = readAsset("rules.json");
            historyJson = readAsset("history.json");
            validatorSystem = readAsset("validator_system.txt");
        } catch (Exception e) {
            fatal("Cannot load embedded THT rules: " + e.getMessage());
            return;
        }
        buildUi();
        if (prefs.getString("api_key", "").isEmpty()) showKeyDialog(true);
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        root.setBackgroundColor(Color.rgb(246,243,237));

        TextView title = new TextView(this);
        title.setText("THE HUMAN THREAD\nAUTOMATIC GATE");
        title.setTextSize(24); title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView expl = new TextView(this);
        expl.setText("\nPaste a THT image request. Validation, repair and gating run automatically. No bypass exists.\n");
        expl.setTextSize(15);
        root.addView(expl);

        requestBox = new EditText(this);
        requestBox.setMinLines(10);
        requestBox.setGravity(Gravity.TOP);
        requestBox.setHint("Paste THT image request here…");
        requestBox.setBackgroundColor(Color.WHITE);
        requestBox.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(requestBox, new LinearLayout.LayoutParams(-1, -2));

        generateButton = new Button(this);
        generateButton.setText("VALIDATE + GENERATE");
        generateButton.setOnClickListener(v -> begin());
        root.addView(generateButton);

        keyButton = new Button(this);
        keyButton.setText("CHANGE API KEY");
        keyButton.setOnClickListener(v -> showKeyDialog(false));
        root.addView(keyButton);

        status = new TextView(this);
        status.setText("\nReady");
        status.setTextSize(14);
        status.setTextIsSelectable(true);
        root.addView(status);

        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        root.addView(imageView, new LinearLayout.LayoutParams(-1, -2));

        sv.addView(root);
        setContentView(sv);
    }

    private void showKeyDialog(boolean mandatory) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint("sk-...");
        AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("OpenAI API key")
            .setMessage("Enter once. Stored only in this app's private storage on this device.")
            .setView(input)
            .setPositiveButton("SAVE", null)
            .setNegativeButton(mandatory ? "EXIT" : "CANCEL", (x,w) -> { if (mandatory) finish(); })
            .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String key = input.getText().toString().trim();
            if (key.length() < 20) { input.setError("Enter a valid API key"); return; }
            prefs.edit().putString("api_key", key).apply();
            d.dismiss();
        }));
        d.setCancelable(!mandatory);
        d.show();
    }

    private void begin() {
        String req = requestBox.getText().toString().trim();
        String key = prefs.getString("api_key", "");
        if (req.isEmpty()) { status.setText("BLOCKED: request is empty"); return; }
        if (key.isEmpty()) { showKeyDialog(true); return; }

        setBusy(true, "Automatic validation started…");
        executor.submit(() -> {
            try {
                JSONObject rules = new JSONObject(rulesJson);
                JSONObject history = new JSONObject(historyJson);
                JSONObject validation = null;
                String repairContext = "";
                boolean eligible = false;
                List<String> finalReasons = new ArrayList<>();

                int maxAttempts = rules.getJSONObject("policy").optInt("automatic_validation_retries", 3);
                for (int attempt = 1; attempt <= maxAttempts; attempt++) {
                    postStatus("Validation pass " + attempt + " of " + maxAttempts + "…");
                    validation = semanticValidate(key, rules, history, req, repairContext);
                    GateResult gr = deterministicGate(rules, validation);
                    if (gr.eligible) {
                        eligible = true;
                        finalReasons.clear();
                        break;
                    }
                    finalReasons = gr.reasons;
                    repairContext = "PRIOR VALIDATION FAILED. Automatically repair only failed dimensions. "
                        + "Prior blocking reasons: " + new JSONArray(gr.reasons).toString()
                        + "\nPrior compiled prompt: " + validation.optString("compiled_prompt", "");
                }

                JSONObject audit = new JSONObject();
                audit.put("timestamp_utc", utcNow());
                audit.put("request", req);
                audit.put("generation_eligible", eligible);
                audit.put("validation", validation == null ? JSONObject.NULL : validation);
                audit.put("gate_reasons", new JSONArray(finalReasons));
                audit.put("rules_sha256", sha256(rulesJson));
                audit.put("history_sha256", sha256(historyJson));

                if (!eligible) {
                    saveAudit(audit);
                    postDone("BLOCKED after automatic validation/repair.\n\n" + joinLines(finalReasons), null);
                    return;
                }

                postStatus("All mandatory checks PASS. Generating exactly one image…");
                String compiledPrompt = validation.getString("compiled_prompt");
                byte[] png = generateOneImage(key, compiledPrompt);
                Uri uri = savePng(png);
                audit.put("generated", true);
                audit.put("image_uri", uri.toString());
                audit.put("image_sha256", sha256(png));
                audit.put("audit_sha256", sha256(audit.toString()));
                saveAudit(audit);
                Bitmap bm = BitmapFactory.decodeByteArray(png, 0, png.length);
                postDone("PASS — exactly one image generated and saved.\n\nAudit hash:\n" + audit.optString("audit_sha256"), bm);
            } catch (Exception e) {
                postDone("BLOCKED: " + e.getClass().getSimpleName() + ": " + e.getMessage(), null);
            }
        });
    }

    private JSONObject semanticValidate(String key, JSONObject rules, JSONObject history, String req, String repairContext) throws Exception {
        JSONObject payloadData = new JSONObject();
        payloadData.put("rules", rules);
        payloadData.put("approved_history", history);
        payloadData.put("pending_request", req);
        if (!repairContext.isEmpty()) payloadData.put("automatic_repair_context", repairContext);

        JSONObject payload = new JSONObject();
        payload.put("model", VALIDATOR_MODEL);
        payload.put("instructions", validatorSystem);
        payload.put("input", payloadData.toString());
        payload.put("text", new JSONObject().put("format", new JSONObject().put("type", "json_object")));

        JSONObject response = postJson(RESPONSES_URL, key, payload);
        String out = extractOutputText(response).trim();
        if (out.startsWith("```")) {
            out = out.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
        }
        return new JSONObject(out);
    }

    private GateResult deterministicGate(JSONObject rules, JSONObject validation) throws Exception {
        List<String> reasons = new ArrayList<>();
        JSONObject checks = validation.optJSONObject("checks");
        JSONObject vetoes = validation.optJSONObject("vetoes");
        if (checks == null) reasons.add("Missing checks object");
        if (vetoes == null) reasons.add("Missing vetoes object");

        JSONArray mandatory = rules.getJSONArray("mandatory_checks");
        for (int i=0; i<mandatory.length(); i++) {
            String id = mandatory.getString(i);
            if (checks == null || !"PASS".equals(checks.optString(id, ""))) reasons.add("CHECK NOT PASS: " + id);
        }
        JSONArray known = rules.getJSONArray("known_failure_vetoes");
        for (int i=0; i<known.length(); i++) {
            String id = known.getString(i);
            if (vetoes == null || !vetoes.optBoolean(id, false)) reasons.add("VETO PRESENT/UNPROVEN: " + id);
        }
        if (validation.optString("compiled_prompt","").trim().isEmpty()) reasons.add("compiled_prompt missing");
        return new GateResult(reasons.isEmpty(), reasons);
    }

    private byte[] generateOneImage(String key, String prompt) throws Exception {
        JSONObject p = new JSONObject();
        p.put("model", IMAGE_MODEL);
        p.put("prompt", prompt);
        p.put("n", 1);
        p.put("size", "1024x1536");
        p.put("quality", "high");
        p.put("output_format", "png");
        JSONObject r = postJson(IMAGES_URL, key, p);
        JSONArray data = r.optJSONArray("data");
        if (data == null || data.length() != 1) throw new Exception("Image API did not return exactly one image");
        String b64 = data.getJSONObject(0).optString("b64_json","");
        if (b64.isEmpty()) throw new Exception("Image payload missing");
        return android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
    }

    private JSONObject postJson(String urlString, String key, JSONObject payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlString).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(30000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        try(OutputStream os = c.getOutputStream()) {
            os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(is);
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("OpenAI API HTTP " + code + ": " + body);
        return new JSONObject(body);
    }

    private String extractOutputText(JSONObject r) throws Exception {
        JSONArray out = r.optJSONArray("output");
        if (out == null) throw new Exception("Validator returned no output");
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<out.length(); i++) {
            JSONObject item = out.optJSONObject(i);
            if (item == null || !"message".equals(item.optString("type"))) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j=0; j<content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c != null && "output_text".equals(c.optString("type"))) sb.append(c.optString("text"));
            }
        }
        if (sb.length()==0) throw new Exception("Validator returned no output_text");
        return sb.toString();
    }

    private Uri savePng(byte[] png) throws Exception {
        String name = "THT_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/The Human Thread");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("Could not create image file");
            try(OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(png); }
            return uri;
        } else {
            File dir = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), "The Human Thread");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create image directory");
            File f = new File(dir, name);
            try(FileOutputStream os = new FileOutputStream(f)) { os.write(png); }
            return Uri.fromFile(f);
        }
    }

    private void saveAudit(JSONObject audit) {
        try {
            File dir = new File(getFilesDir(), "audit"); if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "audit_" + System.currentTimeMillis() + ".json");
            try(FileOutputStream os = new FileOutputStream(f)) {
                os.write(audit.toString(2).getBytes(StandardCharsets.UTF_8));
            }
        } catch(Exception ignored) {}
    }

    private String readAsset(String name) throws Exception {
        try(InputStream in = getAssets().open(name)) { return readAll(in); }
    }
    private String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while((n=in.read(buf))!=-1) b.write(buf,0,n);
        return b.toString("UTF-8");
    }
    private String sha256(String s) throws Exception { return sha256(s.getBytes(StandardCharsets.UTF_8)); }
    private String sha256(byte[] b) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(b);
        StringBuilder sb = new StringBuilder();
        for(byte x:d) sb.append(String.format(Locale.US,"%02x",x));
        return sb.toString();
    }
    private String joinLines(List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<items.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append(items.get(i));
        }
        return sb.toString();
    }
    private String utcNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.format(new Date());
    }
    private void postStatus(String s) { runOnUiThread(() -> status.setText(s)); }
    private void postDone(String s, Bitmap bm) {
        runOnUiThread(() -> {
            status.setText(s); imageView.setImageBitmap(bm); setBusy(false, null);
        });
    }
    private void setBusy(boolean b, String s) {
        generateButton.setEnabled(!b); keyButton.setEnabled(!b); requestBox.setEnabled(!b);
        if (s != null) status.setText(s);
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void fatal(String s) { new AlertDialog.Builder(this).setMessage(s).setPositiveButton("EXIT",(d,w)->finish()).show(); }

    static class GateResult {
        final boolean eligible; final List<String> reasons;
        GateResult(boolean e, List<String> r) { eligible=e; reasons=r; }
    }
}
